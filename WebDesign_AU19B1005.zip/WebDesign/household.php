<?php
    include('dbcs.php');
    //$result = mysqli_query($conn,"SELECT * FROM product");
?>
<!DOCTYPE html>
<html>
     <head>
        <title> Household</title>
		 
		  <style>
			 body{
				 background-color: #E1D5DF;	 
			 }
			 
			 #bg{
				 width: 1050px; height: 120px; border: 1px solid black; 
			 }
			 
			 #title {
				 font-size: 50px;
			 	 color: #fff;
			 	 width: 1050px; 
			 	 background-color: royalblue;
				 margin-top: 60px;
			 	 margin-left: 0px;
			 	 text-align: center;
			 	 -webkit-animation: glow 1s ease-in-out infinite alternate;
			 	 -moz-animation: glow 1s ease-in-out infinite alternate;
			 	 animation: glow 1s ease-in-out infinite alternate;
			 }

			 @-webkit-keyframes glow {
				 from {
				 text-shadow: 0 0 10px #fff, 0 0 15px #fff, 0 0 20px #bcbcbc, 0 0 25px #bcbcbc, 0 0 30px #bcbcbc, 0 0 35px  #e1d5df, 0 0 40px #e1d5df;
				 }

			   to {
				 text-shadow: 0 0 10px #fff, 0 0 15px #ff4da6, 0 0 20px #ff4da6, 0 0 25px #ff4da6, 0 0 30px #ff4da6, 0 0 35px  #ff4da6, 0 0 40px #ff4da6;
			   }
 			 }
			 
			 .product{
				 margin-left: 100px; width: 650px; height: 300px; border: 0px solid black; position: relative; background-color: rgba(255,255,255, 0.9); z-index: -1; border-radius: 25px;
			 }
			 
			 #bu{
				 margin-left: 100px; margin-top: 40px; width: 650px; height: 300px; border: 1px solid black; position: absolute;
			 }

			 .image{
				position: absolute; float: left; margin-left: 50px; margin-top: 50px;
			 }
			 
			 .name{
				position: absolute; margin-left: 420px; margin-top: 30px;
			 }

			 .desc{
				position: absolute; margin-left: 290px; margin-top: 60px;
			 }
			 
			 .addtocart{
				 margin-left: 10px; margin-top: 0px; width: 120px; height: 40px; border: 1px solid black; background-color: darkgray; border-radius: 15px; color: white; font: 16px Century Gothic; cursor: pointer; position: absolute;
			 }
			 
			  
			  body {
				font-family: Arial;
				color: #211a1a;
				font-size: 0.9em;
			}

			
			#product-grid {
				margin: 40px;
			  }


			#btnEmpty {
				background-color: #ffffff;
				border: #d00000 1px solid;
				padding: 5px 10px;
				color: #d00000;
				float: right;
				text-decoration: none;
				border-radius: 3px;
				margin: 10px 0px;
			}

			.btnAddAction {
				padding: 5px 10px;
				margin-left: 5px;
				background-color: #efefef;
				border: #E0E0E0 1px solid;
				color: #211a1a;
				float: right;
				text-decoration: none;
				border-radius: 3px;
				cursor: pointer;
			}
			  .btnAddAction:hover{
				  opacity: 0.7;
				  background-color: grey;
				  color: white;
			  }

			#product-grid .txt-heading {
				margin-bottom: 18px;
			}

			.product-item {
				float: left;
				background-color: rgba(255,255,255, 0.9);
				margin: 10px 30px 0px 0px;
				border: #E0E0E0 1px solid;
				width: 300px;
				height: 395px;
			}

			.product-image {
				height: 155px;
				width: 250px;
				
				margin-left: 49px;
				
			}

			.clear-float {
				clear: both;
			}

			.demo-input-box {
				border-radius: 2px;
				border: #CCC 1px solid;
				padding: 2px 1px;
			}


			.product-title {
				margin-bottom: 20px;
			}

			.product-price {
				float:left;
			}

			.cart-action {
				float: left;
				margin-left: 65px;
			}
			.qty{
				 margin-left: 220px; 
			}

			.product-quantity {
				padding: 3px;
				width: 35px;
				border-radius: 3px;
				border: #E0E0E0 1px solid;
				float: right;
				background-color: transparent;
			}

			.product-tile-footer {
				border: 1px solid black;
				margin-top: 50px;
				height: 185px;
				width: auto;
			}

			
		 </style>
     </head>
	<body>
		
		<div style="position: fixed; border: 0px solid black; width: 1035px;" id="head">
			<?php 
				include('header.php');
			?>
		</div>
		<div id="bg">
			<p id="title">Household Products</p>

		</div>
 
			<div id="product-grid">
				<?php
				$product= mysqli_query($conn,"SELECT * FROM product");
				if (!empty($product)) {
				while ($row=mysqli_fetch_array($product)) {
				?>
				<div class="product-item">
				<form method="post" action="index.php?action=add&pid=<?php echo $row["pro_name"]; ?>">
				<div class="product-image"><img style="height: 200px; width: 200px;" src="<?php echo $row["img"]; ?>"></div>
				<div class="product-tile-footer">
				<div class="product-title"><?php echo $row["descrip"]; ?></div>
				<div class="product-price"><?php echo "Price: Rs. ".$row["pro_price"]; ?></div>
				<div class="qty"><?php echo "Qty: "?><input type="number" class="product-quantity" name="quantity" value="1" size="2" /></div><br>
				<div class="cart-action"><input type="submit" value="Buy Now" class="btnAddAction">
				<input type="submit" value="Add to Cart" class="btnAddAction"></div>
				
				</div>
				</form>
				</div>
				<?php
				}
				} else {
				echo "No Records.";
				}
				?>
				</div>

		
     </body>
</html>