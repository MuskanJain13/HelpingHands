<html>
	<head>
		<!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
	</head>
	<style>
		body {
		  font-family: 'Century Gothic', sans-serif;
		}
		
		#footer_box{
			height: 120px;
			width: 1150px;
			border: 0px solid black;
			position: relative;
		}
		
		#footer{
			background-color: white;
			height: 120px;
			width: 1102px;
			/*margin-top: 2100px;*/
			margin-left: 47px;
			border: 0px solid black;
			position: absolute;
		}

		#f_colorbox{
			background-color: #E1D5DF;
			height: 35px;
			width: 1049px;
			margin-top: 60px;
			margin-left: 26px;
			border: 0px solid black;
			position: absolute;
		}

		#f_topbox{
			background-color: white;
			height: 120px;
			width: 46px;
			border: 0px solid black;
			position: absolute;
		}

		#copyright{
			height: 20px;
			width: 140px;
			position: absolute;
			border: 0px solid black;
			margin-top: 8px;
			margin-left: 15px;
		}

		#privacy{
			margin-top: 8px;
			margin-left: 380px;
			position: absolute;
		}

		#terms{
			margin-top: 8px;
			margin-left: 530px;
			position: absolute;
		}

		#webname{
			margin-top: 8px;
			margin-left: 931px;
			position: absolute;
			border: 0px solid black;
			width: 120px;
		}

		#foll{
			position: absolute;
			height: auto;
			width: 100px;
			margin-top: 16px;
			margin-left: 30px;
			width: 1040px;
			border: 0px solid black;
		}

		#follow{
			position: absolute;
			margin-top: 4px;
		}

		#contactus{
			position: absolute;
			text-align: right;
			margin-top: 4px;
			margin-left: 520px;
			width: 350px;
			border: 0px solid black;
		}

		#textTOP{
			position: absolute;
			margin-left: 0px;
			margin-top: 23px;
			font: 25px Century Gothic;
			color: #E1D5Df;
			transform: rotate(-90deg);
		}
		
	</style>
	<body>
		<div id="footer_box">
			<div id="f_topbox">
				<label id="textTOP">TOP</label>
				<img src="top.png" style="height: 35px;width: 35px; margin-top: 74px; margin-left: 5px;">
			</div>

			<div id="footer">
				<div id="f_colorbox">
					<div id="copyright">
						<img src="copyright.png" style="height: 15px;width: 15px; float: left; padding-right: 5px; margin-top: 2px;">
						Copyright 2020
					</div>
					<label id="privacy">Privacy Policy</label>
					<label id="terms">Terms & Conditions</label>
					<label id="webname">Website Name</label>
				</div>
				<div id="foll">
					<label id="follow">Follow Us</label>
					<img src="facebook.png" style="height: 25px;width: 25px; float: none; padding-right: 5px; margin-left: 95px;">
					<img src="google-plus-logo-on-black-background.png" style="height: 25px;width: 25px; float: none; padding-right: 5px; margin-left: 10px;">
					<label id="contactus">Contact Us at website_name@gmail.com</label>
				</div>
			</div>
		</div>
		
		
	</body>
</html>