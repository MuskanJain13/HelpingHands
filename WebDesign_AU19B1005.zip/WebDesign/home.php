<html>
    <head>
        <title>Homepage</title>
        <link rel="stylesheet" href="homepagestyle.css">
    </head>
    <body>
        <div id="div1">
			<div id="top">
				<p style="text-align: center">Life never stops... Be unstoppable!</p>
			</div>
			<div style="position: fixed" id="head">
				<?php 
					include('header.php');
				?>
			</div>
            <div id="covid">
                <h3 style="text-align: center">COVID UPDATES</h3>
            </div>
            <div id="image1">
                <img src="image1_DP.jpg" style="width: 611px; height: 600px">
            </div>
            <div id="image2">
                <img src="image2.jpg" style="width: 537px; height: 300px; position: absolute">
            </div>
            <div id="image3">
                <img src="image3.PNG" style="width: 537px; height: 300px; position: absolute">
            </div>
            <div id="image4">
                <img src="image4.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
            <div id="image5">
                <img src="image5.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
             <div id="image6">
                <img src="image6.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
             <div id="image7">
                <img src="image7.jpg" style="width: 930px; height: 197px; position: absolute">
            </div>
            <div id="image8">
                <img src="image8.PNG" style="width: 930px; height: 197px; position: absolute">
            </div>
             <div id="image9">
                <img src="image9.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
            <div id="image10">
                <img src="image10.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
            <div id="image11">
                <img src="image11.jpg" style="width: 219px; height: 329px; position: absolute">
            </div>
            
            <div id="text">
                Is Covid 19 stopping you for buying necessary products...?
                Are you hesitating for that 
                What are you waiting for...? Here we are with all the necessary household products and we'll deliver all the sanitized products with safety measures.
                Keep your house clean with all the necessary household products
            </div>
            <div id="text1">
               In this pandemic many people lost their jobs and it's difficult to find new jobs for the new ones also.
                So, on this platform they can find appropiate jobs for themselves.
                We provide a platform to all the recruiters  and the retailers who want employees/workers and have vacancies in there companies/shops.
            </div>
            
             <div id="sn1">
                 <button id = "b1" type="button" style="border: 0px; background-color: transparent">BUY NOW</button>
             </div>
            <div id="sn2">
                <button id = "b2" type="button" style="border: 0px; background-color: transparent">GET EMPLOYEE</button>
             </div>
            <div id="sn3">
                <button id = "b3" type="button" style="border: 0px; background-color: transparent">FIND JOB</button>
             </div>
             <div id="sn4">
                <button id = "b4" type="button" style="border: 0px; background-color: transparent">SHOP NOW</button>
             </div>
             <div id="sn5">
                <button id = "b5" type="button" style="border: 0px; background-color: transparent">SHOP NOW</button>
             </div>
             <div id="sn6">
                <button id = "b6" type="button" style="border: 0px; background-color: transparent">SHOP NOW</button>
             </div>
            <div id="sn7">
                <button id = "b7" type="button" style="border: 0px; background-color: transparent">GET YOURS NOW</button>
             </div>
            <div id="sn8">
                <button id = "b8" type="button" style="border: 0px; background-color: transparent">SHOP NOW</button>
             </div>
            <div id="sn9">
                <button id = "b9" type="button" style="border: 0px; background-color: transparent">GET JOB IN AUTOBILE SECTOR</button>
             </div>
             <div id="sn10">
                <button id = "b10" type="button" style="border: 0px; background-color: transparent">FIND EMPLOYEE FOR DELIVERY</button>
             </div>
            <div id="sn11">
                <button id = "b11" type="button" style="border: 0px; background-color: transparent">GET JOB AND WORK FROM HOME</button>
             </div>
			
			
			
			<!--<div id="f_topbox">
					<label id="textTOP">Top</label>
					<img src="top.png" style="height: 40px;width: 40px; margin-top: 70px; margin-left: 2px;">
				</div>
			
			<div id="footer">
				<div id="f_colorbox">
					<div id="copyright">
						<img src="copyright.png" style="height: 15px;width: 15px; float: left; padding-right: 5px; margin-top: 2px;">
						Copyright 2020
					</div>
					<label id="privacy">Privacy Policy</label>
					<label id="terms">Terms & Conditions</label>
					<label id="webname">Website Name</label>
				</div>
				<div id="foll">
					<label id="follow">Follow Us</label>
					<img src="facebook.png" style="height: 25px;width: 25px; float: none; padding-right: 5px; margin-left: 95px;">
					<img src="google-plus-logo-on-black-background.png" style="height: 25px;width: 25px; float: none; padding-right: 5px; margin-left: 10px;">
					<label id="contactus">Contact Us at website_name@gmail.com</label>
				</div>
			</div>-->
        </div>

		<div style="position: sticky" id="head">
			<?php 
				include_once('footer.php');
			?>
		</div>
    </body>
</html>