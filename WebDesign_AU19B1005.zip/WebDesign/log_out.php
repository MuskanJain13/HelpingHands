<?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['password']);
echo "YOU have cleaned up the session";
    header ('location: index.php');
?>

