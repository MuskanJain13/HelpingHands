-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2020 at 06:12 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid_solution`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Full_name` varchar(255) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `pre_comp` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `cont_no` bigint(20) NOT NULL,
  `Qualifications` varchar(255) NOT NULL,
  `exp` varchar(255) DEFAULT NULL,
  `comm` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Full_name`, `Age`, `Gender`, `pre_comp`, `email`, `cont_no`, `Qualifications`, `exp`, `comm`) VALUES
('Abc', 25, 'male', '', 'a@a', 919279898911, '12th pass', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pro_id` int(11) NOT NULL,
  `pro_name` varchar(255) NOT NULL,
  `pro_price` float NOT NULL,
  `pro_quantity` int(11) NOT NULL,
  `batch_no` int(11) NOT NULL,
  `manf_date` date NOT NULL,
  `exp_date` date NOT NULL,
  `descrip` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `pro_name`, `pro_price`, `pro_quantity`, `batch_no`, `manf_date`, `exp_date`, `descrip`, `img`) VALUES
(1, 'Harpic', 250, 50, 2526, '2020-11-25', '2021-03-25', '<p>A cleaner for toilets wich remove 99.99% germs </p> <p> a cleaner for toilets wich remove 99.99% germs</p>', 'harpic-india.png'),
(2, 'vim', 250, 50, 2526, '2020-11-25', '2021-03-25', 'Vim for kitchen wich remove 99.99% germs', 'vim.png'),
(3, 'hello', 250, 50, 2526, '2020-11-25', '2021-03-25', 'A cleaner for toilets wich remove 99.99% germs', 'house.png'),
(4, 'hello', 250, 50, 2526, '2020-11-25', '2021-03-25', 'jhf jkshd fjkf kjfk md ich reve 99.99 rms', 'image1_DP.jpg'),
(5, 'elo', 250, 50, 2526, '2020-11-25', '2021-03-25', 'jhf jkshd fjkf kjfk md ich reve 99.99 rms', 'image4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `recruiter`
--

CREATE TABLE `recruiter` (
  `company_name` varchar(255) NOT NULL,
  `company_add` varchar(255) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `authorised_person` varchar(255) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `job_profile` varchar(255) NOT NULL,
  `no_vacancies` int(11) NOT NULL,
  `work_hr` varchar(255) NOT NULL,
  `pay_policy` int(11) DEFAULT NULL,
  `job_desc` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `age_criteria` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recruiter`
--

INSERT INTO `recruiter` (`company_name`, `company_add`, `company_email`, `authorised_person`, `contact`, `job_profile`, `no_vacancies`, `work_hr`, `pay_policy`, `job_desc`, `qualification`, `age_criteria`) VALUES
('Abc', 'asddas', 'a@w', 'aa', 918328493823, 'asmnsjkd', 4, '3', 783, 'sndhjsbdsjdh', 'jasdhjksdfh', '19 - 30 yrs.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `contact`, `address`, `username`, `password`) VALUES
(NULL, 'eku@gmail.com', NULL, NULL, 'ekta20', 'Eello201'),
(NULL, 's@e', NULL, NULL, 'hello15', '123456aA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pro_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
