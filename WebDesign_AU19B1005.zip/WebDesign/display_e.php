<html>
    <head>
        <title>Employee Info</title>
        <style>
            #bg{
                border: 1px solid black;
                height: 613px;
                width: 1328px;
                background-color: #E1D5DF;
                position: relative;
                
            }
            #d1{
                position: absolute;
                margin-top: 310px;
                margin-left: 150px;
            }
            #d2{
                position: absolute;
                height: 40px;
                width: 350px;
                background-color: transparent;
                margin-top: 280px;
                margin-left: 480px;
            }
            #d3{
                height: 200px;
                width: 400px;
                border: 1px solid black;
                margin-top: 30px;
                margin-left: 450px;
            }
            td,th{
                border: 1px solid white;
                text-align: center;
                background-color: #BCBCBC;
                height: 20px;
            }
            
            td{
                height: 40px;
                width: 200px;
            }
            th{
                height: 40px;
            }
            
        </style>
    </head>
    <body>
        <div id="bg">
            <a href = "index.php"><img src="house.png" style="height: 30px; width: 30px;position: absolute; margin-left:6px; margin-top:6px;"></a>

        <div id="d1">
        <?php
            include('dbcs.php');
           $sql = (mysqli_query($conn,"SELECT `Full_name`,`Age`,`email`,`cont_no`,`Qualifications` FROM employee e, recruiter r WHERE e.Qualifications = r.qualification"));
            ?>
            <table class="table table-bordered">
                <tr class="info">
                    <th>Name: </th>
                    <th>Age: </th>
                    <th>Em@il: </th>
                    <th>Contact: </th>
                    <th>Qualifications: </th>
                </tr>
                
            <?php

            if(mysqli_num_rows($sql)>0){
                while($row = mysqli_fetch_assoc($sql))
                {
                  echo '
                    <tr>
                    <td>' . $row['Full_name'] . '</td>
                    <td>' . $row['Age'] . '</td>
                    <td>' . $row['email'] . '</td>
                    <td>' . $row['cont_no'] . '</td>
                    <td>' . $row['Qualifications'] . '</td>
                    </tr>';
                        }
                        echo '</table>';
                }
            else{
                echo "zero result";
            }
                
            ?>
            
            </div>
            <div id="d2">
                Employee Details matched to your entered demands
            </div>
            <div id="d3">
                <img src="Capture.PNG" style="height: 200px; width: 400px">
            </div>
        </div>

    </body>
</html>