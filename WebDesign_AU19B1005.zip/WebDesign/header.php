<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: 'Century Gothic', sans-serif;
}

.overlay {
	height: 100%;
  	width: 0;
	position: fixed;
  	top: 0;
  	left: 0;
  	background-color: rgba(211, 212, 207, 0.98);
  	overflow-x: hidden;
	transition: 1.5s;
}

.overlay-content {
  	border: 0px solid black;
  	position: relative;
  	top: 20%;
  	left: 10%;
	width: 600px;
  	margin-top: 5px;
}

.overlay a {
  	text-decoration: none;
  	font-size: 36px;
  	color: #818181;
  	display: block;
  	transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  	color: #ffffff;
}

.overlay .closebtn {
  	position: absolute;
  	top: 5px;
  	right: 45px;
  	font-size: 60px;
}	

#a_u{
	margin-left: 250px;
	padding-top: 22px;
}

#f{
	margin-left: 400px;
	padding-top: 22px;
}

#s_n{
	margin-left: 400px;
	padding-top: 8px;
}
	
#f_b{
	margin-left: 400px;
	padding-top: 8px;
}

#g_e{
	margin-left: 400px;
	padding-top: 8px;
}
	
#faq{
	margin-left: 540px;
	padding-top: 22px;
}

#con{
	margin-left: 622px;
	padding-top: 22px;
}
	
@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}
</style>
</head>
<body>
	<img src="search.png" style="width:32px; height:32px; float: right; margin-top: 10px">
	<a href="cart.html"><img src="shopping-cart-of-checkered-design.png" style="width:32px; height:32px; float: right; margin-right: 20px; margin-top: 10px"></a>
	<button id = "ls" style="width: 80px; height: 30px; background-color: white; margin-top: 10px; margin-left: 850px; position: absolute"><a style="text-decoration: none;" href="login.php">sign in</a></button>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
	  <a href="index.php"><img style="width: 30px; height: 30px; position: absolute" src="house.png"></a>
    <a id="a_u" href="#">About Us</a>
    <a id="f" href="#">Facilities</a>
		<a id="s_n" style="font-size: 20px;" href="household.php">Shop Now</a>
	  	<a id="f_b" style="font-size: 20px;" href="employee.php">Find Job</a>
	  	<a id="g_e" style="font-size: 20px;" href="recruiter.php">Get Employee</a>
    <a id="faq" href="#">FAQs</a>
    <a id="con" href="#">Contact</a>
  </div>
</div>

<span style="font-size:30px;cursor:pointer; margin-left: 10px; color: white" onclick="openNav()">&#9776; open</span>

<script>
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>
     
</body>
</html>